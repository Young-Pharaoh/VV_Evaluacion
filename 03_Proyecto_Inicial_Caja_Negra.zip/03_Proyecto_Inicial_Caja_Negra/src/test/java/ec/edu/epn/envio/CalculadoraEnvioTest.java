package ec.edu.epn.envio;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CalculadoraEnvioTest {

    private final CalculadoraEnvio calculadora = new CalculadoraEnvio();

    // Cree aquí sus métodos @Test a partir de los casos diseñados en su documento de evidencias.

}
